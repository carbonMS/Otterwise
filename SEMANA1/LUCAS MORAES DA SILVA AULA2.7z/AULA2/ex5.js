// 05 - Faça um programa que armazene dois valores nas variáveis valor1 e valor2.
// Efetue a soma de valor1 e valor2 atribuindo o seu resultado na variável
// resultado. Imprima no console o valor armazenado em resultado.
// Exemplo de Entrada 1:
// 10
// 5
// Exemplo de Entrada 2:
// 8
// -3
// Exemplo de Saída 1:
// 15
// Exemplo de Saída 2:
// 5

let valor1 = 10
let valor2 = 5
let resultado = valor1 + valor2

console.log(resultado)
