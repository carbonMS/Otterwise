// 02 - Atribua a uma constante a soma das strings "Otter" e "wise" e imprima no
// console seu valor.
// Saída Esperada:
// Otterwise

const otterwise = 'Otter' + 'wise'

console.log(otterwise)
