// 01 - Faça um programa que imprima no console uma frase que contenha seu
// nome e sua formação.
// Exemplo de Saída:
// Meu nome é Juca e eu sou formado em Sistemas de Informação.

console.log('Meu nome é Lucas e sou formado em Gestão Pública')
