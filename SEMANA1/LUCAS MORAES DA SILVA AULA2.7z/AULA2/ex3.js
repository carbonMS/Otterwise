// 03 - Faça um programa que armazene em duas variáveis distintas, um nome e
// um sobrenome, e imprima no console o nome completo.
// Exemplo de Saída:
// Gabriel Barros

let name = 'Lucas'
let lastName = 'Moraes da Silva'
console.log(name, lastName)
