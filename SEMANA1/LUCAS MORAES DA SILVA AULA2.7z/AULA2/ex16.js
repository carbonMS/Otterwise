// 16 - Escreva um programa que receba como entrada dois valores. Após, o
// programa deve mostrar uma mensagem “São Múltiplos” ou “Não são Múltiplos”,
// indicando se os valores recebidos como entrada são múltiplos entre si.

let value1 = 4
let value2 = 2

if (value1 % value2 === 0) {
  console.log(value1 + ' é multiplo de ' + value2)
} else {
  console.log(value1 + ' não é multiplo de ' + value2)
}
