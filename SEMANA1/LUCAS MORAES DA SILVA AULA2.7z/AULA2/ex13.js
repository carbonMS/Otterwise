// 13 - Tendo como informação um número, faça um programa que imprime no
// console se esse número é par ou ímpar.
// Os valores de entrada serão:
// Número;
// Exemplo de Entrada:
// 50
// -----------------
// 17
// Exemplo de Saída:
// Par
// -----------------
// Ímpar

let number = 11

if (number % 2 === 0) {
  console.log(number + ' é par')
} else {
  console.log(number + ' é ímpar')
}
