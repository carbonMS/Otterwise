// 04 - Imprima no console a multiplicação de 42 por -3.14.
// Saída esperada:
// -131.88

console.log(42 * -3.14)
