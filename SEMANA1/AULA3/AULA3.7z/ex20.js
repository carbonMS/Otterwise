// 20 - Crie uma função chamada double que possui um parâmetro (que será um
//     número) e retorna o dobro desse número.
//     Exemplo de Entrada:
//     10
//     -----------------
//     -5
//     Exemplo de Saída:
//     20
//     -----------------
//     -10

function double(num) {
  return num * 2
}

console.log(double(10))
