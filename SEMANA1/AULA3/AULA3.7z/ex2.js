// 2. Crie um programa que some os números 5, 10 e 15. Salve o resultado em uma variável e imprima no console.

let soma = 5 + 10 + 15
console.log(soma)
