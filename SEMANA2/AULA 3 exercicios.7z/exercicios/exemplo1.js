// Crie uma função que recebe duas notas como argumento e retorna a média entre elas.
// Utilize arrow function e atribua a uma constante.

const average = (gradeOne, gradeTwo) => {
  return (gradeOne + gradeTwo) / 2;
};

console.log(average(10, 5));
