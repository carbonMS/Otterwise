// 19 - Crie um algoritmo que tem como entrada um array de strings e trata essas
// string substituindo os números por letra de acordo com a tabela a seguir, além
// disso, deve remover os espaços em branco no começo e fim da string, se
// existirem.
// Tabela:
// 1 : i
// 3 : e
// 4 : a
// 5 : s
// 0 : o
// Exemplo entrada:
let stringIt = [' h3ll0 w0rld', ' w3b d3v3l0p3r ', '0tterw1s3', 'j4v4scr1pt ']
// Exemplo Saída:
// [ 'helloworld', 'webdeveloper', 'otterwise', 'javascript' ]

function replaceNum(array) {
  for (let index = 0; index < array.length; index++) {}
}
replaceNum(stringIt)

// if (array) {
//   console.log(
//     element
//       .replace(' ', '')
//       .replace(' ', '')
//       .replace('3', 'e')
//       .replace('0', 'o')
//       .replace('4', 'a')
//       .replace('3', 'e')
//       .replace('3', 'e')
//       .replace('3', 'e')
//       .replace('0', 'o')
//       .replace('4', 'a')
//       .replace('1', 'i')
//   )
// }
