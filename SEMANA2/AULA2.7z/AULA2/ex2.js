// 2 - Imprima no console os valores de 10 até 200 de 10 em 10.
// Saída Esperada:
// 10
// 20
// 30
// 40
// 50
// 60
// 70
// 80
// 90
// 100
// 110
// 120
// 130
// 140
// 150
// 160
// 170
// 180
// 190
// 200

for (let index = 10; index <= 200; index += 10) {
  console.log(index)
}
